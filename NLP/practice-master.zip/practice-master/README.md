# practice
练习项目

**NER**：命名实体识别（BiLSTM+CRF，Keras），目前只是把流程跑通，后续还需调优

**TF-IDF**：文本关键词提取的Python实现（jieba 和 sklearn)

**text-classification**：中文短文本分类（TextCNN，Keras）

**Word2Vec**：词向量实践（gensim）
